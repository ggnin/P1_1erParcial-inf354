import pandas as pd
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

class DS:
    # Constructor parametrizado
    def __init__(self, filename):
        self.df = pd.read_csv(filename)
        self.numeric_features = ['SepalLengthCm', 'SepalWidthCm', 'PetalLengthCm', 'PetalWidthCm']
        self.categorical_features = ['Species']
        self.preprocessor = None
        self.processed_df = None

    # Método para mostrar las primeras filas del DataFrame
    def mostrar(self):
        print(self.df.head())
        
    # Método para aplicar escalado estándar a las características numéricas
    def apply_standard_scaling(self):
        """
        Aplica el escalado estándar a las características numéricas.
        """
        numeric_transformer = Pipeline(steps=[
            ('scaler', StandardScaler())
        ])
        
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('num', numeric_transformer, self.numeric_features)
            ],
            remainder='passthrough'  # Conserva las columnas no transformadas
        )
        
        self.processed_df = pd.DataFrame(self.preprocessor.fit_transform(self.df))
    
    # Método para aplicar codificación One-Hot a la característica categórica 'Species'
    def apply_one_hot_encoding(self):
        """
        Aplica codificación One-Hot a la característica categórica 'Species'.
        """
        categorical_transformer = Pipeline(steps=[
            ('onehot', OneHotEncoder())
        ])
        
        self.preprocessor = ColumnTransformer(
            transformers=[
                ('cat', categorical_transformer, self.categorical_features)
            ],
            remainder='passthrough'  # Conserva las columnas no transformadas
        )
        
        self.processed_df = pd.DataFrame(self.preprocessor.fit_transform(self.df))
    
    # Método para simular la selección de características (ejemplo didáctico)
    def apply_feature_selection(self):
        """
        Simula la selección de características (ejemplo didáctico).
        """
        print("Selección de características aplicada.")
        self.processed_df = self.df  # No se realiza ninguna transformación en este ejemplo didáctico
    
    # Método para simular la normalización de características (ejemplo didáctico)
    def apply_feature_normalization(self):
        """
        Simula la normalización de características (ejemplo didáctico).
        """
        print("Normalización de características aplicada.")
        self.processed_df = self.df  # No se realiza ninguna transformación en este ejemplo didáctico
    
    # Método para simular la aumentación de datos (ejemplo didáctico)
    def apply_data_augmentation(self):
        """
        Simula la aumentación de datos (ejemplo didáctico).
        """
        print("Aumentación de datos aplicada.")
        self.processed_df = self.df  # No se realiza ninguna transformación en este ejemplo didáctico
    
    # Método para mostrar el DataFrame procesado
    def show_processed_data(self):
        """
        Muestra el DataFrame procesado.
        """
        if self.processed_df is not None:
            print("Dataset procesado:")
            print(self.processed_df.head())
        else:
            print("¡Primero aplica un algoritmo de preprocesamiento!")

# Uso del dataset con los métodos definidos
if __name__ == "__main__":
    dataset = DS('iris.csv')
    dataset.mostrar()
    
    # Aplicar escalado estándar
    print("\nAplicando escalado estándar...")
    dataset.apply_standard_scaling()
    dataset.show_processed_data()
    
    # Aplicar codificación One-Hot
    print("\nAplicando codificación One-Hot...")
    dataset.apply_one_hot_encoding()
    dataset.show_processed_data()
    
    # Ejemplo de aplicar selección de características (simulado)
    print("\nSimulando selección de características...")
    dataset.apply_feature_selection()
    dataset.show_processed_data()
    
    # Ejemplo de aplicar normalización de características (simulado)
    print("\nSimulando normalización de características...")
    dataset.apply_feature_normalization()
    dataset.show_processed_data()
    
    # Ejemplo de aplicar aumentación de datos (simulado)
    print("\nSimulando aumentación de datos...")
    dataset.apply_data_augmentation()
    dataset.show_processed_data()
