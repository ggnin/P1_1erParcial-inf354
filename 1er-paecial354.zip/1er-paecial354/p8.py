import itertools

# Definición de los nodos del grafo
nodos = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']

# Generar todas las permutaciones de los nodos
permutaciones = list(itertools.permutations(nodos))

# Imprimir las permutaciones (solo para visualizar, no es necesario imprimir todas)
for perm in permutaciones:
    print(perm)
