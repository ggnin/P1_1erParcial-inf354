print("Hola mundo")
