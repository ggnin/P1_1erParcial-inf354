import csv
from math import prod, pow

# Cargar el archivo iris.csv
file_path = 'iris.csv'

# Leer el archivo CSV y almacenar los datos
data = []
with open(file_path, 'r') as file:
    reader = csv.reader(file)
    headers = next(reader)
    for row in reader:
        try:
            # Convertir los primeros cuatro valores a float, y el resto como están
            converted_row = [float(val) if i < 4 else val for i, val in enumerate(row)]
            data.append(converted_row)
        except ValueError as e:
            print(f"Error en la fila {reader.line_num}: {e}")

# Separar las columnas
columns = list(zip(*data))

# Función para calcular la media
def mean(column):
    # Filtrar elementos no numéricos y convertir a float
    filtered_column = [float(x) for x in column if isinstance(x, (int, float))]
    return sum(filtered_column) / len(filtered_column)

# Función para calcular la mediana (se mantiene igual)
def median(column):
    sorted_col = sorted(column)
    n = len(sorted_col)
    mid = n // 2
    if n % 2 == 0:
        return (sorted_col[mid - 1] + sorted_col[mid]) / 2
    else:
        return sorted_col[mid]

# Función para calcular la moda (se mantiene igual)
def mode(column):
    frequency = {}
    for value in column:
        if value in frequency:
            frequency[value] += 1
        else:
            frequency[value] = 1
    max_freq = max(frequency.values())
    modes = [key for key, value in frequency.items() if value == max_freq]
    if len(modes) == 1:
        return modes[0]
    else:
        return modes

# Función para calcular la media geométrica (se mantiene igual)
def geometric_mean(column):
    return pow(prod(column), 1 / len(column))

# Calcular y mostrar resultados por columna
for i, header in enumerate(headers[:-1]):  # Excluir la última columna
    column = columns[i]
    print(f"{header}:")
    try:
        print(f"  Media: {mean(column)}")
        print(f"  Mediana: {median(column)}")
        print(f"  Moda: {mode(column)}")
        print(f"  Media geométrica: {geometric_mean(column)}")
    except ZeroDivisionError:
        print("  No se puede calcular la media porque la columna contiene solo valores no numéricos.")
    print()
