class Persona:
    def __init__(self, nombre, edad, genero):
        self.nombre = nombre
        self.edad = edad
        self.genero = genero
        self.padres = []
        self.hijos = []
        self.abuelos = []
        self.tios = []
        self.primos = []
    
    def agregar_padre(self, padre):
        if padre is not None:  # Verificar si se proporciona un padre válido
            self.padres.append(padre)
            padre.agregar_hijo(self)
            # Agregar abuelos paternos
            for abuelo in padre.padres:
                if abuelo not in self.abuelos:
                    self.abuelos.append(abuelo)
                    abuelo.agregar_nieto(self)
            # Agregar tíos paternos
            for tio in padre.hermanos():
                if tio not in self.tios:
                    self.tios.append(tio)
                    tio.agregar_sobrino(self)
    
    def agregar_hijo(self, hijo):
        self.hijos.append(hijo)
    
    def agregar_nieto(self, nieto):
        self.hijos.append(nieto)
    
    def agregar_sobrino(self, sobrino):
        self.primos.append(sobrino)
    
    def agregar_tio(self, tio):
        self.tios.append(tio)
    
    def agregar_primo(self, primo):
        self.primos.append(primo)
    
    def hermanos(self):
        hermanos = []
        if self.padres:
            for padre in self.padres:
                for hijo in padre.hijos:
                    if hijo != self and hijo not in hermanos:
                        hermanos.append(hijo)
        return hermanos
    
    def __str__(self):
        return f"{self.nombre} ({self.edad} años, {self.genero})"

# Crear personas
juan = Persona("Juan", 60, "Hombre")
ana = Persona("Ana", 58, "Mujer")
carlos = Persona("Carlos", 35, "Hombre")
luisa = Persona("Luisa", 30, "Mujer")
pedro = Persona("Pedro", 32, "Hombre")
maria = Persona("Maria", 28, "Mujer")
lucas = Persona("Lucas", 5, "Hombre")
sofia = Persona("Sofía", 3, "Mujer")

# Establecer relaciones familiares
juan.agregar_padre(None)  # Juan no tiene información de sus padres
ana.agregar_padre(None)   # Ana no tiene información de sus padres

# Padres de Carlos y Luisa
carlos.agregar_padre(juan)
carlos.agregar_padre(ana)
luisa.agregar_padre(juan)
luisa.agregar_padre(ana)

# Padres de Pedro y María
pedro.agregar_padre(juan)
pedro.agregar_padre(ana)
maria.agregar_padre(juan)
maria.agregar_padre(ana)

# Padres de Lucas y Sofía
lucas.agregar_padre(carlos)
lucas.agregar_padre(luisa)
sofia.agregar_padre(carlos)
sofia.agregar_padre(luisa)

# Mostrar relaciones familiares
print(f"Abuelos de Lucas y Sofía:")
for abuelo in lucas.abuelos:
    print(f"- {abuelo}")

print(f"\nTíos de Lucas y Sofía:")
for tio in lucas.tios:
    print(f"- {tio}")

print(f"\nPadres de Lucas y Sofía:")
for padre in lucas.padres:
    print(f"- {padre}")

print(f"\nPrimos de Lucas y Sofía:")
for primo in lucas.primos:
    print(f"- {primo}")

print(f"\nHijos de Juan y Ana:")
for hijo in juan.hijos + ana.hijos:
    print(f"- {hijo}")

