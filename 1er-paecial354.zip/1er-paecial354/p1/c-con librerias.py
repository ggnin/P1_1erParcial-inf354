import pandas as pd
import numpy as np
from scipy.stats import gmean


file_path = 'iris.csv'  
df = pd.read_csv(file_path)

# Calcular la media......................
mean_values = df.iloc[:, :-1].mean()

# Calcular la mediana........................
median_values = df.iloc[:, :-1].median()

# Calcular la moda.................................
mode_values = df.iloc[:, :-1].mode().iloc[0]

# Calcular la media geométrica..........................
gmean_values = gmean(df.iloc[:, :-1], axis=0)


print("Media:")
print(mean_values)
print("\nMediana:")
print(median_values)
print("\nModa:")
print(mode_values)
print("\nMedia geométrica:")
print(gmean_values)
