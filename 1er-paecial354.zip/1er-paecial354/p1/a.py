def read_csv(file_path):
    with open(file_path, 'r') as file:
        data = [line.strip().split(',') for line in file.readlines()]
    return data

# Leer el archivo iris.csv
data = read_csv('iris.csv')[1:]  # Omitir encabezados

# Convertir a valores numéricos (asumiendo las primeras 4 columnas son características numéricas)
for row in data:
    for i in range(4):
        row[i] = float(row[i])

# Transponer los datos para trabajar por columna
data_t = list(zip(*data))

# Función para calcular percentiles sin usar librerías
def percentile(data, percent):
    k = (len(data) - 1) * percent
    f = int(k)
    c = k - f
    if f + 1 < len(data):
        return data[f] + (data[f + 1] - data[f]) * c
    else:
        return data[f]

# Calcular el último cuartil (percentil 75) y percentil 80 por columna
quartiles = []
percentiles_80 = []
for column in data_t[:4]:  # Solo las primeras 4 columnas
    column_sorted = sorted(column)
    quartiles.append(percentile(column_sorted, 0.75))
    percentiles_80.append(percentile(column_sorted, 0.80))

print("Último cuartil por columna:", quartiles)
print("Percentil 80 por columna:", percentiles_80)
