import pandas as pd
import numpy as np

df = pd.read_csv('iris.csv')

# Calcular el último cuartil (percentil 75) y percentil 80 por columna
quartiles_np = np.percentile(df.iloc[:, :-1], 75, axis=0)
percentiles_80_np = np.percentile(df.iloc[:, :-1], 80, axis=0)

print("Último cuartil por columna (NumPy):", quartiles_np)
print("Percentil 80 por columna (NumPy):", percentiles_80_np)

quartiles_pd = df.iloc[:, :-1].quantile(0.75)
percentiles_80_pd = df.iloc[:, :-1].quantile(0.80)

print("Último cuartil por columna (Pandas):", quartiles_pd)
print("Percentil 80 por columna (Pandas):", percentiles_80_pd)
